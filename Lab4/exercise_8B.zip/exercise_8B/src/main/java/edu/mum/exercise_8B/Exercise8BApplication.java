package edu.mum.exercise_8B;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Exercise8BApplication {

	public static void main(String[] args) {
		SpringApplication.run(Exercise8BApplication.class, args);
	}
}
